package kwanty;

public class Prostokat {
	public int x;
	public int y;
	public double z;
}
